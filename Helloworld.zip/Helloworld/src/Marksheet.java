public class Marksheet{


    static void total(int maths,int science,int english){ //no return type with parameter
        System.out.println("Total marks="+(maths+science+english));
    System.out.println("Percentage="+(maths+science+english)*100/300);}

// java main method
    public static void main(String[] args){
        total  (65,78,70);
    }
}




