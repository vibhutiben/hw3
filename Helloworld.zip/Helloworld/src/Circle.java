public class Circle {
// java main method
    public static void main(String[]args){
        int radius =5;
        double area = Math.PI*radius*radius;
        System.out.println( area);
    }


}
